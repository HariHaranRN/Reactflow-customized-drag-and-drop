export const NodeTypes = [
    {key:"default", name: "Default"},
    {key:"circle", name: "Cirlce"},
    {key:"textInput", name: "Text Field"},
    {key:"selectionBox", name: "Selection Box"},
]